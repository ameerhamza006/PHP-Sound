<?php
require 'header.php';
?>


Here Add Your HTML Content.....






<?php
require 'footer.php';
?>